#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include <numeric>
#include <algorithm>
#include <random>
#include <ctime>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <chrono>
#include <list>
#include <deque>

using std::accumulate;
using std::string;
using std::vector;
using std::cout;
using std::cin;
using std::endl;
using std::sort;
using std::left;
using std::right;
using std::setw;
using std::setprecision;
using std::fixed;
using std::ifstream;
using std::ostream;
using std::cerr;
using std::getline;
using std::runtime_error;
using std::exception;
using std::ofstream;
using namespace std::chrono;

using std::list;
using std::deque;




